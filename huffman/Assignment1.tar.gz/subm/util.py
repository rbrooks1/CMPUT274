import bitio
import huffman
import pickle
import sys


def read_tree(tree_stream):
    '''Read a description of a Huffman tree from the given compressed
    tree stream, and use the pickle module to construct the tree object.
    Then, return the root node of the tree itself.

    Args:
      tree_stream: The compressed stream o read the tree from.

    Returns:
      A Huffman tree root constructed according to the given description.
    '''
    try:
        huffTree = pickle.load(tree_stream).root
        return(huffTree)
    except Exception:
        sys.exit(-1)


def decode_byte(tree, bitreader):
    """
    Reads bits from the bit reader and traverses the tree from
    the root to a leaf. Once a leaf is reached, bits are no longer read
    and the value of that leaf is returned.

    Args:
      bitreader: An instance of bitio.BitReader to read the tree from.
      tree: A Huffman tree.

    Returns:
      Next byte of the compressed bit stream.
    """
    while True:
        if type(tree) == huffman.TreeLeaf:
            return(tree.value)
        elif type(tree) == huffman.TreeBranch:
            bit = bitreader.readbit()
            if bit == 0:
                tree = tree.left
            else:
                tree = tree.right


def decompress(compressed, uncompressed):
    '''First, read a Huffman tree from the 'tree_stream' using your
    read_tree function. Then use that tree to decode the rest of the
    stream and write the resulting symbols to the 'uncompressed'
    stream.

    Args:
      compressed: A file stream from which compressed input is read.
      uncompressed: A writable file stream to which the uncompressed
          output is written.
    '''
    tree = read_tree(compressed)
    bitRead = bitio.BitReader(compressed)
    bitWrite = bitio.BitWriter(uncompressed)
    while True:
        try:
            result = decode_byte(tree, bitRead)
            bitWrite.writebits(result, 8)
            bitWrite.flush()
        except EOFError:
            break


def write_tree(tree, tree_stream):
    '''Write the specified Huffman tree to the given tree_stream
    using pickle.

    Args:
      tree: A Huffman tree.
      tree_stream: The binary file to write the tree to.
    '''
    try:
        pickle.dump(tree, tree_stream)
    except Exception:
        sys.exit(-1)


def compress(tree, uncompressed, compressed):
    '''First write the given tree to the stream 'tree_stream' using the
    write_tree function. Then use the same tree to encode the data
    from the input stream 'uncompressed' and write it to 'compressed'.
    If there are any partially-written bytes remaining at the end,
    write 0 bits to form a complete byte.

    Flush the bitwriter after writing the entire compressed file.

    Args:
      tree: A Huffman tree.
      uncompressed: A file stream from which you can read the input.
      compressed: A file stream that will receive the tree description
          and the coded input data.
    '''
    # the if statement checks if the files are open in the correct mode
    if compressed.mode == 'wb' and uncompressed.mode == 'rb':
        write_tree(tree, compressed)
        writeBit = bitio.BitWriter(compressed)
        readBit = bitio.BitReader(uncompressed)
        huff = huffman.make_encoding_table(tree.root)
        while True:
            try:
                byte = readBit.readbits(8)
                for boolean in huff[byte]:
                    writeBit.writebit(boolean)
            except EOFError:
                writeBit.flush()
                compressed.flush()
                break
    else:
        print('file error')
        compressed.close()
        uncompressed.close()
        sys.exit(-1)
